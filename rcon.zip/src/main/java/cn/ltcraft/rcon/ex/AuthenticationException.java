package cn.ltcraft.rcon.ex;

public class AuthenticationException extends Exception {

	public AuthenticationException(String message) {
		super(message);
	}
	
}
